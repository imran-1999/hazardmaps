package com.example.hazardmaps;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Information {

    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("time_date")
    @Expose
    public String timeDate;
    @SerializedName("type")
    @Expose
    public String type;
    @SerializedName("location")
    @Expose
    public String location;
    @SerializedName("description")
    @Expose
    public String description;
    @SerializedName("lng")
    @Expose
    public String lng;
    @SerializedName("lat")
    @Expose
    public String lat;

}